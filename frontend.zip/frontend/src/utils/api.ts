export const API_BASE = 'http://localhost:5000/api';

export const apiCall = async (endpoint: string, options: RequestInit = {}) => {
  const url = `${API_BASE}${endpoint}`;
  const token = localStorage.getItem('token');
  
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` }),
    ...options.headers,
  };

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Network error' }));
    throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
  }

  return response.json();
};

// Games API functions
export const gamesAPI = {
  // Get all games with pagination, search, and filters
  getAllGames: async (params: {
    page?: number;
    limit?: number;
    gameType?: string;
    search?: string;
  } = {}) => {
    const queryParams = new URLSearchParams();
    
    if (params.page) queryParams.append('page', params.page.toString());
    if (params.limit) queryParams.append('limit', params.limit.toString());
    if (params.gameType) queryParams.append('gameType', params.gameType);
    if (params.search) queryParams.append('search', params.search);

    return apiCall(`/games/admin?${queryParams.toString()}`);
  },

  // Create a new game
  createGame: async (gameData: {
    nickName: string;
    startTime: string;
    endTime: string;
    gameType: string;
    isActive?: boolean;
  }) => {
    return apiCall('/games', {
      method: 'POST',
      body: JSON.stringify(gameData),
    });
  },

  // Update an existing game
  updateGame: async (id: string, gameData: {
    nickName?: string;
    startTime?: string;
    endTime?: string;
    gameType?: string;
    isActive?: boolean;
  }) => {
    return apiCall(`/games/${id}`, {
      method: 'PUT',
      body: JSON.stringify(gameData),
    });
  },

  // Delete a game (soft delete)
  deleteGame: async (id: string) => {
    return apiCall(`/games/${id}`, {
      method: 'DELETE',
    });
  },

  // Publish game result
  publishResult: async (gameId: string, result: string) => {
    return apiCall('/results', {
      method: 'POST',
      body: JSON.stringify({
        gameId,
        result,
      }),
    });
  },
};

// Utility function to handle API errors
export const handleAPIError = (error: unknown): string => {
  if (error instanceof Error) {
    return error.message;
  }
  return 'An unexpected error occurred';
};