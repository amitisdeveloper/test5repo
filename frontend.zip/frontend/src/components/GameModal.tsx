import { useState, useEffect } from 'react';
import { X } from 'lucide-react';

interface Game {
  _id?: string;
  nickName: string;
  startTime: string;
  endTime: string;
  gameType: 'local' | 'prime';
  isActive: boolean;
  latestResult?: {
    result: string;
    date: string;
    time: string;
  } | null;
}

interface GameModalProps {
  isOpen: boolean;
  onClose: () => void;
  game?: Game | null;
  mode: 'create' | 'edit' | 'publish';
  onSubmit: (data: any) => Promise<void>;
}

function GameModal({ isOpen, onClose, game, mode, onSubmit }: GameModalProps) {
  const [formData, setFormData] = useState({
    nickName: '',
    startTime: '',
    endTime: '',
    gameType: 'local' as 'local' | 'prime',
    isActive: true,
    result: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (game && (mode === 'edit' || mode === 'publish')) {
      setFormData({
        nickName: game.nickName || '',
        startTime: game.startTime ? new Date(game.startTime).toISOString().slice(0, 16) : '',
        endTime: game.endTime ? new Date(game.endTime).toISOString().slice(0, 16) : '',
        gameType: game.gameType || 'local',
        isActive: game.isActive,
        result: game.latestResult?.result || ''
      });
    } else if (mode === 'create') {
      // Reset form for create mode
      const now = new Date();
      const later = new Date(now.getTime() + 60 * 60 * 1000); // 1 hour later
      
      setFormData({
        nickName: '',
        startTime: now.toISOString().slice(0, 16),
        endTime: later.toISOString().slice(0, 16),
        gameType: 'local',
        isActive: true,
        result: ''
      });
    }
    setError('');
  }, [game, mode, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (mode === 'publish') {
        await onSubmit({
          result: formData.result,
          gameId: game?._id
        });
      } else {
        await onSubmit(formData);
      }
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const getModalTitle = () => {
    switch (mode) {
      case 'create': return 'Create New Game';
      case 'edit': return 'Edit Game';
      case 'publish': return 'Publish Game Result';
      default: return 'Game Modal';
    }
  };

  const getSubmitButtonText = () => {
    if (loading) {
      switch (mode) {
        case 'create': return 'Creating...';
        case 'edit': return 'Updating...';
        case 'publish': return 'Publishing...';
        default: return 'Loading...';
      }
    }
    switch (mode) {
      case 'create': return 'Create Game';
      case 'edit': return 'Update Game';
      case 'publish': return 'Publish Result';
      default: return 'Submit';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-br from-amber-950/90 via-neutral-900 to-amber-950/90 rounded-xl border-2 border-yellow-600/40 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-yellow-600/30">
          <h2 className="text-2xl font-bold text-yellow-400">{getModalTitle()}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {mode !== 'publish' && (
            <>
              {/* Game Name */}
              <div>
                <label className="block text-sm font-medium text-yellow-400 mb-2">
                  Game Name *
                </label>
                <input
                  type="text"
                  value={formData.nickName}
                  onChange={(e) => setFormData({ ...formData, nickName: e.target.value })}
                  className="w-full px-4 py-3 bg-neutral-800 border border-yellow-600/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  placeholder="Enter game name"
                  required
                  disabled={mode === 'edit' && !!game?.latestResult}
                />
              </div>

              {/* Game Type */}
              <div>
                <label className="block text-sm font-medium text-yellow-400 mb-2">
                  Game Type *
                </label>
                <select
                  value={formData.gameType}
                  onChange={(e) => setFormData({ ...formData, gameType: e.target.value as 'local' | 'prime' })}
                  className="w-full px-4 py-3 bg-neutral-800 border border-yellow-600/30 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  required
                  disabled={mode === 'edit' && !!game?.latestResult}
                >
                  <option value="local">Local</option>
                  <option value="prime">Prime</option>
                </select>
              </div>

              {/* Start Time */}
              <div>
                <label className="block text-sm font-medium text-yellow-400 mb-2">
                  Start Time *
                </label>
                <input
                  type="datetime-local"
                  value={formData.startTime}
                  onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                  className="w-full px-4 py-3 bg-neutral-800 border border-yellow-600/30 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  required
                />
              </div>

              {/* End Time */}
              <div>
                <label className="block text-sm font-medium text-yellow-400 mb-2">
                  End Time *
                </label>
                <input
                  type="datetime-local"
                  value={formData.endTime}
                  onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                  className="w-full px-4 py-3 bg-neutral-800 border border-yellow-600/30 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  required
                />
              </div>

              {/* Active Status */}
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="w-4 h-4 text-yellow-600 bg-neutral-800 border-yellow-600/30 rounded focus:ring-yellow-500 focus:ring-2"
                />
                <label htmlFor="isActive" className="text-sm font-medium text-yellow-400">
                  Active Game
                </label>
              </div>
            </>
          )}

          {mode === 'publish' && (
            <div>
              <label className="block text-sm font-medium text-yellow-400 mb-2">
                Game Result *
              </label>
              <input
                type="text"
                value={formData.result}
                onChange={(e) => setFormData({ ...formData, result: e.target.value })}
                className="w-full px-4 py-3 bg-neutral-800 border border-yellow-600/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                placeholder="Enter the game result"
                required
              />
              <p className="text-gray-400 text-sm mt-1">
                Publishing result for: <span className="text-yellow-400 font-medium">{game?.nickName}</span>
              </p>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="text-red-400 text-sm bg-red-900/20 border border-red-600/30 rounded-lg p-3">
              {error}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-gradient-to-r from-green-600 to-green-700 text-white font-bold py-3 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {getSubmitButtonText()}
            </button>
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="flex-1 bg-gradient-to-r from-gray-600 to-gray-700 text-white font-bold py-3 rounded-lg hover:from-gray-700 hover:to-gray-800 transition-all duration-300 disabled:opacity-50"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default GameModal;