import { X } from 'lucide-react';

interface GameChartProps {
  gameName: string;
  onClose: () => void;
}

function GameChart({ gameName, onClose }: GameChartProps) {
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-br from-amber-950/90 via-neutral-900 to-amber-950/90 rounded-xl p-6 border-2 border-yellow-600/40 max-w-4xl w-full max-h-[80vh] overflow-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-yellow-400">{gameName} - Game Chart</h2>
          <button
            onClick={onClose}
            className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-lg transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        
        <div className="bg-neutral-800/50 rounded-lg p-6">
          <div className="text-center text-gray-400">
            <p>Game chart for {gameName} coming soon!</p>
            <p className="text-sm mt-2">This will display historical data and trends.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GameChart;