import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, LogOut, AlertCircle } from 'lucide-react';
import GamesTable from './GamesTable';
import GameModal from './GameModal';
import { gamesAPI, handleAPIError } from '../utils/api';

interface Game {
  _id: string;
  nickName: string;
  startTime: string;
  endTime: string;
  gameType: 'local' | 'prime';
  isActive: boolean;
  latestResult?: {
    result: string;
    date: string;
    time: string;
  } | null;
}

interface Pagination {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  hasNext: boolean;
  hasPrev: boolean;
}

function AdminDashboardGames() {
  const [games, setGames] = useState<Game[]>([]);
  const [pagination, setPagination] = useState<Pagination>({
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    itemsPerPage: 10,
    hasNext: false,
    hasPrev: false
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Search and filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('');
  
  // Modal states
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    mode: 'create' | 'edit' | 'publish';
    game: Game | null;
  }>({
    isOpen: false,
    mode: 'create',
    game: null
  });

  const navigate = useNavigate();

  useEffect(() => {
    fetchGames();
  }, [pagination.currentPage, searchTerm, filterType]);

  const fetchGames = async () => {
    try {
      setLoading(true);
      setError('');

      const params: any = {
        page: pagination.currentPage,
        limit: 10
      };

      if (searchTerm) {
        params.search = searchTerm;
      }

      if (filterType && filterType !== '') {
        params.gameType = filterType === 'active' || filterType === 'completed' ? undefined : filterType;
        params.status = filterType;
      }

      const response = await gamesAPI.getAllGames(params);
      
      setGames(response.games || []);
      setPagination({
        ...pagination,
        ...response.pagination
      });
    } catch (err) {
      console.error('Error fetching games:', err);
      setError(handleAPIError(err));
      
      if (err instanceof Error && err.message.includes('Invalid token')) {
        localStorage.removeItem('token');
        navigate('/admin/login');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSearchChange = (term: string) => {
    setSearchTerm(term);
    setPagination(prev => ({ ...prev, currentPage: 1 }));
  };

  const handleFilterChange = (filter: string) => {
    setFilterType(filter);
    setPagination(prev => ({ ...prev, currentPage: 1 }));
  };

  const handlePageChange = (page: number) => {
    setPagination(prev => ({ ...prev, currentPage: page }));
  };

  const openModal = (mode: 'create' | 'edit' | 'publish', game?: Game) => {
    setModalState({
      isOpen: true,
      mode,
      game: game || null
    });
    setError('');
    setSuccess('');
  };

  const closeModal = () => {
    setModalState({
      isOpen: false,
      mode: 'create',
      game: null
    });
    setError('');
    setSuccess('');
  };

  const handleGameSubmit = async (data: any) => {
    try {
      setError('');
      
      if (modalState.mode === 'create') {
        await gamesAPI.createGame(data);
        setSuccess('Game created successfully!');
      } else if (modalState.mode === 'edit') {
        await gamesAPI.updateGame(modalState.game!._id, data);
        setSuccess('Game updated successfully!');
      }
      
      // Refresh games list
      await fetchGames();
    } catch (err) {
      throw new Error(handleAPIError(err));
    }
  };

  const handleDeleteGame = async (game: Game) => {
    if (!confirm(`Are you sure you want to delete "${game.nickName}"?`)) {
      return;
    }

    try {
      setError('');
      await gamesAPI.deleteGame(game._id);
      setSuccess('Game deleted successfully!');
      await fetchGames();
    } catch (err) {
      setError(handleAPIError(err));
    }
  };

  const handlePublishResult = async (data: any) => {
    try {
      setError('');
      await gamesAPI.publishResult(data.gameId, data.result);
      setSuccess('Result published successfully!');
      await fetchGames();
    } catch (err) {
      throw new Error(handleAPIError(err));
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/admin/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-neutral-950 via-neutral-900 to-neutral-950">
      {/* Header */}
      <header className="bg-gradient-to-r from-amber-950/80 to-neutral-900 border-b border-yellow-600/30 p-4">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-yellow-400">Games Management</h1>
          <div className="flex gap-4">
            <button
              onClick={() => openModal('create')}
              className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-2 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-300"
            >
              <Plus size={20} />
              Create Game
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-red-700 text-white px-4 py-2 rounded-lg hover:from-red-700 hover:to-red-800 transition-all duration-300"
            >
              <LogOut size={20} />
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto p-6">
        {/* Status Messages */}
        {error && (
          <div className="mb-6 flex items-center gap-3 text-red-400 text-sm bg-red-900/20 border border-red-600/30 rounded-lg p-4">
            <AlertCircle size={20} />
            {error}
          </div>
        )}

        {success && (
          <div className="mb-6 flex items-center gap-3 text-green-400 text-sm bg-green-900/20 border border-green-600/30 rounded-lg p-4">
            <AlertCircle size={20} />
            {success}
          </div>
        )}

        {/* Games Table */}
        <GamesTable
          games={games}
          pagination={pagination}
          loading={loading}
          searchTerm={searchTerm}
          filterType={filterType}
          onSearchChange={handleSearchChange}
          onFilterChange={handleFilterChange}
          onPageChange={handlePageChange}
          onEdit={(game) => openModal('edit', game)}
          onDelete={handleDeleteGame}
          onPublishResult={(game) => openModal('publish', game)}
        />

        {/* Summary Stats */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-blue-950/70 via-neutral-900 to-blue-950/70 rounded-lg p-4 border border-blue-600/30">
            <div className="text-blue-400 text-sm font-medium">Total Games</div>
            <div className="text-2xl font-bold text-white">{pagination.totalItems}</div>
          </div>
          <div className="bg-gradient-to-br from-green-950/70 via-neutral-900 to-green-950/70 rounded-lg p-4 border border-green-600/30">
            <div className="text-green-400 text-sm font-medium">Active Games</div>
            <div className="text-2xl font-bold text-white">
              {games.filter(g => g.isActive && !g.latestResult).length}
            </div>
          </div>
          <div className="bg-gradient-to-br from-purple-950/70 via-neutral-900 to-purple-950/70 rounded-lg p-4 border border-purple-600/30">
            <div className="text-purple-400 text-sm font-medium">Completed</div>
            <div className="text-2xl font-bold text-white">
              {games.filter(g => g.latestResult).length}
            </div>
          </div>
          <div className="bg-gradient-to-br from-amber-950/70 via-neutral-900 to-amber-950/70 rounded-lg p-4 border border-amber-600/30">
            <div className="text-amber-400 text-sm font-medium">Inactive</div>
            <div className="text-2xl font-bold text-white">
              {games.filter(g => !g.isActive).length}
            </div>
          </div>
        </div>
      </main>

      {/* Game Modal */}
      <GameModal
        isOpen={modalState.isOpen}
        onClose={closeModal}
        game={modalState.game}
        mode={modalState.mode}
        onSubmit={modalState.mode === 'publish' ? handlePublishResult : handleGameSubmit}
      />
    </div>
  );
}

export default AdminDashboardGames;