interface LatestUpdatesProps {
  latestResult: any;
  isLoading: boolean;
}

function LatestUpdates({ latestResult, isLoading }: LatestUpdatesProps) {
  if (isLoading) {
    return (
      <div className="container mx-auto px-4">
        <div className="bg-gradient-to-br from-amber-950/70 via-neutral-900 to-amber-950/70 rounded-xl p-6 border-2 border-yellow-600/40 shadow-xl">
          <div className="animate-pulse">
            <div className="h-4 bg-yellow-600/20 rounded w-1/3 mb-4"></div>
            <div className="h-6 bg-yellow-600/10 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4">
      <div className="bg-gradient-to-br from-amber-950/70 via-neutral-900 to-amber-950/70 rounded-xl p-6 border-2 border-yellow-600/40 shadow-xl">
        <div className="text-center">
          <h2 className="text-lg font-bold text-yellow-400 mb-4">Latest Updates</h2>
          {latestResult ? (
            <div className="space-y-2">
              <p className="text-green-400 font-semibold">Latest Result: {latestResult.result}</p>
              <p className="text-gray-400 text-sm">{latestResult.name} - {latestResult.time}</p>
            </div>
          ) : (
            <p className="text-gray-400">No recent updates</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default LatestUpdates;