import { useState } from 'react';
import { ChevronLeft, ChevronRight, Search, Filter, Edit, Trash2, Trophy } from 'lucide-react';

interface Game {
  _id: string;
  nickName: string;
  startTime: string;
  endTime: string;
  gameType: 'local' | 'prime';
  isActive: boolean;
  latestResult?: {
    result: string;
    date: string;
    time: string;
  } | null;
}

interface Pagination {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  hasNext: boolean;
  hasPrev: boolean;
}

interface GamesTableProps {
  games: Game[];
  pagination: Pagination;
  loading: boolean;
  searchTerm: string;
  filterType: string;
  onSearchChange: (term: string) => void;
  onFilterChange: (filter: string) => void;
  onPageChange: (page: number) => void;
  onEdit: (game: Game) => void;
  onDelete: (game: Game) => Promise<void>;
  onPublishResult: (game: Game) => void;
}

function GamesTable({
  games,
  pagination,
  loading,
  searchTerm,
  filterType,
  onSearchChange,
  onFilterChange,
  onPageChange,
  onEdit,
  onDelete,
  onPublishResult
}: GamesTableProps) {
  const getStatusBadge = (game: Game) => {
    if (!game.isActive) {
      return (
        <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-900/50 text-red-400 border border-red-600/30">
          Inactive
        </span>
      );
    }

    if (game.latestResult) {
      return (
        <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-900/50 text-green-400 border border-green-600/30">
          Completed
        </span>
      );
    }

    return (
      <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-900/50 text-blue-400 border border-blue-600/30">
        Active
      </span>
    );
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const renderPaginationButtons = () => {
    const buttons = [];
    const { currentPage, totalPages, hasPrev, hasNext } = pagination;

    // Previous button
    buttons.push(
      <button
        key="prev"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={!hasPrev || loading}
        className="px-3 py-2 text-sm font-medium text-gray-300 bg-neutral-800 border border-yellow-600/30 rounded-l-lg hover:bg-neutral-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <ChevronLeft size={16} />
      </button>
    );

    // Page numbers
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);

    if (startPage > 1) {
      buttons.push(
        <button
          key={1}
          onClick={() => onPageChange(1)}
          disabled={loading}
          className="px-3 py-2 text-sm font-medium text-gray-300 bg-neutral-800 border border-yellow-600/30 hover:bg-neutral-700 disabled:opacity-50"
        >
          1
        </button>
      );
      if (startPage > 2) {
        buttons.push(
          <span key="ellipsis1" className="px-3 py-2 text-sm text-gray-500">...</span>
        );
      }
    }

    for (let i = startPage; i <= endPage; i++) {
      buttons.push(
        <button
          key={i}
          onClick={() => onPageChange(i)}
          disabled={loading}
          className={`px-3 py-2 text-sm font-medium border border-yellow-600/30 ${
            i === currentPage
              ? 'bg-yellow-600 text-black'
              : 'text-gray-300 bg-neutral-800 hover:bg-neutral-700'
          } disabled:opacity-50`}
        >
          {i}
        </button>
      );
    }

    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        buttons.push(
          <span key="ellipsis2" className="px-3 py-2 text-sm text-gray-500">...</span>
        );
      }
      buttons.push(
        <button
          key={totalPages}
          onClick={() => onPageChange(totalPages)}
          disabled={loading}
          className="px-3 py-2 text-sm font-medium text-gray-300 bg-neutral-800 border border-yellow-600/30 hover:bg-neutral-700 disabled:opacity-50"
        >
          {totalPages}
        </button>
      );
    }

    // Next button
    buttons.push(
      <button
        key="next"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!hasNext || loading}
        className="px-3 py-2 text-sm font-medium text-gray-300 bg-neutral-800 border border-yellow-600/30 rounded-r-lg hover:bg-neutral-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <ChevronRight size={16} />
      </button>
    );

    return buttons;
  };

  return (
    <div className="bg-gradient-to-br from-amber-950/70 via-neutral-900 to-amber-950/70 rounded-lg border-2 border-yellow-600/40 overflow-hidden">
      {/* Header with Search and Filter */}
      <div className="p-6 border-b border-yellow-600/30">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search games..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-neutral-800 border border-yellow-600/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
            />
          </div>

          {/* Filter */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <select
              value={filterType}
              onChange={(e) => onFilterChange(e.target.value)}
              className="pl-10 pr-8 py-2 bg-neutral-800 border border-yellow-600/30 rounded-lg text-white focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 appearance-none"
            >
              <option value="">All Types</option>
              <option value="local">Local</option>
              <option value="prime">Prime</option>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-neutral-800/50">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-medium text-yellow-400 uppercase tracking-wider">
                Game
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-yellow-400 uppercase tracking-wider">
                Type
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-yellow-400 uppercase tracking-wider">
                Schedule
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-yellow-400 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-yellow-400 uppercase tracking-wider">
                Latest Result
              </th>
              <th className="px-6 py-4 text-right text-xs font-medium text-yellow-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-yellow-600/20">
            {loading ? (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-gray-400">
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-yellow-400 mr-3"></div>
                    Loading games...
                  </div>
                </td>
              </tr>
            ) : games.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-gray-400">
                  No games found
                </td>
              </tr>
            ) : (
              games.map((game) => (
                <tr key={game._id} className="hover:bg-neutral-800/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-white">{game.nickName}</div>
                    <div className="text-xs text-gray-400">
                      ID: {game._id.slice(-8)}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      game.gameType === 'prime'
                        ? 'bg-purple-900/50 text-purple-400 border border-purple-600/30'
                        : 'bg-blue-900/50 text-blue-400 border border-blue-600/30'
                    }`}>
                      {game.gameType.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-300">
                      <div>Start: {formatDateTime(game.startTime)}</div>
                      <div>End: {formatDateTime(game.endTime)}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(game)}
                  </td>
                  <td className="px-6 py-4">
                    {game.latestResult ? (
                      <div className="text-sm">
                        <div className="text-green-400 font-medium">{game.latestResult.result}</div>
                        <div className="text-xs text-gray-400">
                          {formatDateTime(game.latestResult.date)}
                        </div>
                      </div>
                    ) : (
                      <span className="text-xs text-gray-500">No results yet</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      {!game.latestResult && (
                        <button
                          onClick={() => onPublishResult(game)}
                          className="p-2 text-blue-400 hover:text-blue-300 hover:bg-blue-900/20 rounded-lg transition-colors"
                          title="Publish Result"
                        >
                          <Trophy size={16} />
                        </button>
                      )}
                      <button
                        onClick={() => onEdit(game)}
                        className="p-2 text-yellow-400 hover:text-yellow-300 hover:bg-yellow-900/20 rounded-lg transition-colors"
                        title="Edit Game"
                      >
                        <Edit size={16} />
                      </button>
                      <button
                        onClick={async () => {
                          try {
                            await onDelete(game);
                          } catch (error) {
                            console.error('Delete failed:', error);
                          }
                        }}
                        className="p-2 text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded-lg transition-colors"
                        title="Delete Game"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {pagination.totalPages > 1 && (
        <div className="px-6 py-4 border-t border-yellow-600/30">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-400">
              Showing {((pagination.currentPage - 1) * pagination.itemsPerPage) + 1} to{' '}
              {Math.min(pagination.currentPage * pagination.itemsPerPage, pagination.totalItems)} of{' '}
              {pagination.totalItems} games
            </div>
            <div className="flex items-center space-x-1">
              {renderPaginationButtons()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default GamesTable;