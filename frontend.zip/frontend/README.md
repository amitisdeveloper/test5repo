# 555 Results Frontend

A modern React frontend application for the 555 Results live gaming platform.

## Features

- **React 18** with TypeScript
- **Vite** for fast development and building
- **Tailwind CSS** for styling
- **React Router** for navigation
- **Chart.js** for data visualization
- **Lucide React** for icons
- **Responsive design** with dark theme

## Project Structure

```
frontend/
├── src/
│   ├── components/          # React components
│   │   ├── AdminDashboard.tsx
│   │   ├── AdminLogin.tsx
│   │   ├── CreateGame.tsx
│   │   ├── GameChart.tsx
│   │   ├── GameResult.tsx
│   │   ├── LatestUpdates.tsx
│   │   └── ProtectedRoute.tsx
│   ├── utils/
│   │   └── api.ts          # API utilities
│   ├── App.tsx             # Main application component
│   ├── main.tsx            # Application entry point
│   └── index.css           # Global styles
├── public/                 # Static assets
├── index.html              # HTML template
├── package.json            # Dependencies and scripts
├── vite.config.ts          # Vite configuration
├── tsconfig.json           # TypeScript configuration
├── tailwind.config.js      # Tailwind CSS configuration
└── .env                    # Environment variables
```

## Prerequisites

- Node.js (v16 or higher)
- npm or yarn

## Installation

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

## Environment Variables

Create a `.env` file in the frontend directory:

```env
VITE_API_URL=http://localhost:5000/api
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Development

Start the development server:

```bash
npm run dev
```

The application will be available at `http://localhost:5173`

## Building for Production

```bash
npm run build
```

The production files will be generated in the `dist` directory.

## Features Overview

### Public Pages
- **Home Page**: Displays live games, results, and latest updates
- **Game Charts**: Visual representation of game data

### Admin Pages
- **Admin Login**: Secure authentication for administrators
- **Admin Dashboard**: Game management interface
- **Create Game**: Form to create new games
- **Publish Results**: Interface to publish game results

### API Integration
The frontend communicates with the backend API at `http://localhost:5000/api` for:
- User authentication
- Game management
- Result publishing
- Data retrieval

## Technology Stack

- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **React Router** - Routing
- **Chart.js** - Charts
- **Lucide React** - Icons

## Contributing

1. Follow the existing code style
2. Use TypeScript for all new code
3. Test your changes thoroughly
4. Update documentation as needed